def get_response(user_input: str) -> str:
    raise NotImplementedError('Code is missing...')
